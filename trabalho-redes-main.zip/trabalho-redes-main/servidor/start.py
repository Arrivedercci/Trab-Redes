from server import server_controller

if __name__ == '__main__':
    server_controller()
    
    print('done')